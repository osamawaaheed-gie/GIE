# GIE — GitHub Pages Site

This folder is ready to publish on GitHub Pages.

## Steps
1. Create a new GitHub repository (e.g., `gie-website`).
2. Upload the files in this folder (`index.html`, `logo.png`, `GIE_Company_Profile_Expanded_v2.pdf`).
3. In the repository settings, enable **Pages**:
   - Source: `Deploy from a branch`
   - Branch: `main` / root (`/`)
4. Your site will be available at: `https://<your-username>.github.io/<repo-name>/`

You can edit `index.html` directly to update text or colors.
